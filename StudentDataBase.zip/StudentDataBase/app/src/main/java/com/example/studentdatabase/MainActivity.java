package com.example.studentdatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import com.example.studentdatabase.Studentdb.MyDataBase;

public class MainActivity extends AppCompatActivity {
    EditText etRoll, etName, etMarks, etCgpa;
    ListView lv;
    Button btnInsert;


    MyDataBase mdb = new MyDataBase(this);
    Cursor cursor;
    SimpleCursorAdapter sca;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etRoll = findViewById(R.id.editRollNo);
        etName = findViewById(R.id.editName);
        etMarks = findViewById(R.id.editMarks);
        etCgpa = findViewById(R.id.editCgpa);

        lv = findViewById(R.id.listStudentDetails);

        btnInsert = findViewById(R.id.buttonInsert);
        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Long roll = Long.parseLong(etRoll.getText().toString().trim());
                String strName = etName.getText().toString().trim();
                Integer Marks = Integer.parseInt(etMarks.getText().toString().trim());
                Float cgpa = Float.parseFloat(etCgpa.getText().toString().trim());


                mdb.empInsert(new ContentValues());
                Toast.makeText(MainActivity.this, "Data inserted successfully", Toast.LENGTH_SHORT).show();



                ContentValues cv = new ContentValues();
                cv.put("roll",roll);
                cv.put("name", strName);
                cv.put("marks", Marks);
                cv.put("cgpa",cgpa);

                etRoll.setText(null);
                etName.setText(null);
                etMarks.setText(null);
                etCgpa.setText(null);

                cursor.requery();


            }
        });

        cursor = mdb.getEmp();

        String[] from = {"roll", "name", "marks", "cgpa"};
        int[] to = {R.id.textViewRollNo, R.id.textViewName, R.id.textViewMarks, R.id.textViewCGPA};

        sca = new SimpleCursorAdapter(this, R.layout.row, cursor, from, to, 0);

        lv.setAdapter(sca);

        sca.notifyDataSetChanged();
        cursor.requery();


    }
}
