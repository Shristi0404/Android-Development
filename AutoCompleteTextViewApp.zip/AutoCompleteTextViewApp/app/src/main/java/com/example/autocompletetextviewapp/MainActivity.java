package com.example.autocompletetextviewapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

public class MainActivity extends AppCompatActivity {
    //wigdets
    AutoCompleteTextView actv;
    String[] lng = {"C", "C++","JAVA","PYTHON","Swift", "Javascript", "React native","Android", "PHP","Kotlin","OOP","C#","SQL","HTML","CSS","R,","RUBY","MATLAB","RUST","Scala","NoSql","Perl"};

    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        actv=findViewById(R.id.autoCompleteTextView);
        adapter = new ArrayAdapter<String>(this, android.R.layout.select_dialog_item,lng);


        actv.setThreshold(1);
        actv.setAdapter(adapter);
        actv.setTextColor(Color.GREEN);


    }
}