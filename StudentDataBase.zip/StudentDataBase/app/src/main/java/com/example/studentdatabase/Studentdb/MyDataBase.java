package com.example.studentdatabase.Studentdb;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class MyDataBase  {
    public static final String DBNAME= "stuDB";
    SQLiteDatabase sdb;
    Context con;
    MyHelper mh;

    public MyDataBase(Context context){

        this.con = context;
        mh = new MyHelper(con,DBNAME,null,1);
    }

    //Lets create method to insert the data
    public void empInsert(ContentValues cv){
        sdb = mh.getWritableDatabase();
        sdb.insert("employee", null,cv);

    }
    public Cursor getEmp(){

        sdb = mh.getReadableDatabase();
        Cursor c =  sdb.query("employee", null, null, null, null, null,
                null);
        return c;
    }

}
